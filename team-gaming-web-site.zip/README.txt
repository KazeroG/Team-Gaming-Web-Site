A Pen created at CodePen.io. You can find this one at http://codepen.io/Kazerog/pen/xVyxML.

 Original Pen [doPNga](http://codepen.io/ForgottenUndead/pen/doPNga/).